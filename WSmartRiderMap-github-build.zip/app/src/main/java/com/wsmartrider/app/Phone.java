package com.wsmartrider.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;

import java.util.List;

/** Fungsi bantu HP: musik, volume, telepon, baterai. */
final class Phone {
    static final class MusicInfo {
        String title = "", artist = "", app = "", pkg = "";
        boolean playing;
    }

    static volatile MediaController controller;

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** Info musik yang sedang aktif, atau null (butuh izin akses notifikasi). */
    static MusicInfo music(Context c) {
        try {
            MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> l = m.getActiveSessions(new ComponentName(c, NotifService.class));
            if (l == null || l.isEmpty()) {
                controller = null;
                return null;
            }
            MediaController pick = l.get(0);
            for (MediaController mc : l) {
                PlaybackState p = mc.getPlaybackState();
                if (p != null && p.getState() == PlaybackState.STATE_PLAYING) {
                    pick = mc;
                    break;
                }
            }
            controller = pick;
            MusicInfo r = new MusicInfo();
            PlaybackState ps = pick.getPlaybackState();
            r.pkg = nz(pick.getPackageName());
            r.playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
            MediaMetadata md = pick.getMetadata();
            if (md != null) {
                r.title = nz(md.getString(MediaMetadata.METADATA_KEY_TITLE));
                r.artist = nz(md.getString(MediaMetadata.METADATA_KEY_ARTIST));
                if (r.artist.isEmpty()) r.artist = nz(md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST));
            }
            try {
                PackageManager pm = c.getPackageManager();
                r.app = pm.getApplicationLabel(pm.getApplicationInfo(r.pkg, 0)).toString();
            } catch (Exception e) {
                r.app = r.pkg;
            }
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    /** 0 putar, 1 jeda, 2 sebelumnya, 3 berikutnya, 4 putar/jeda. */
    static void musicControl(Context c, int code) {
        try {
            MediaController mc = controller;
            if (mc != null) {
                MediaController.TransportControls t = mc.getTransportControls();
                switch (code) {
                    case 0: t.play(); return;
                    case 1: t.pause(); return;
                    case 2: t.skipToPrevious(); return;
                    case 3: t.skipToNext(); return;
                    default: {
                        PlaybackState p = mc.getPlaybackState();
                        if (p != null && p.getState() == PlaybackState.STATE_PLAYING) t.pause();
                        else t.play();
                        return;
                    }
                }
            }
            int key;
            switch (code) {
                case 0: key = KeyEvent.KEYCODE_MEDIA_PLAY; break;
                case 1: key = KeyEvent.KEYCODE_MEDIA_PAUSE; break;
                case 2: key = KeyEvent.KEYCODE_MEDIA_PREVIOUS; break;
                case 3: key = KeyEvent.KEYCODE_MEDIA_NEXT; break;
                default: key = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE; break;
            }
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, key));
        } catch (Exception ignored) {
        }
    }

    /** op: 0 atur level (0-100), 1 naik, 2 turun, 3 bisukan. */
    static void volume(Context c, int op, int level) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            if (op == 0) {
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int idx = Math.round(Math.max(0, Math.min(100, level)) * max / 100f);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0);
            } else if (op == 1) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0);
            } else if (op == 2) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0);
            } else {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0);
            }
        } catch (Exception ignored) {
        }
    }

    static int callState(Context c) {
        try {
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            return tm.getCallState();
        } catch (Exception e) {
            return TelephonyManager.CALL_STATE_IDLE;
        }
    }

    static boolean answer(Context c) {
        try {
            TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            tm.acceptRingingCall();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean reject(Context c) {
        try {
            if (Build.VERSION.SDK_INT < 28) return false;
            TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            return tm.endCall();
        } catch (Exception e) {
            return false;
        }
    }

    /** {persen, 1 jika sedang mengisi daya}. */
    static int[] battery(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return new int[]{100, 0};
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
        int pct = scale > 0 ? (level * 100 / scale) : level;
        return new int[]{Math.max(0, Math.min(100, pct)), ch ? 1 : 0};
    }
}
