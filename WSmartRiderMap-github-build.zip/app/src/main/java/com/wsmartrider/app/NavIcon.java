package com.wsmartrider.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.zip.CRC32;

/** Ikon belokan 48x48 hitam-putih (288 byte, bit paling kiri = bit 7) untuk layar navigasi Chronos. */
final class NavIcon {
    static final int S = 48;

    static int crc(byte[] d) {
        CRC32 c = new CRC32();
        c.update(d, 0, d.length);
        return (int) c.getValue();
    }

    private static byte[] pack(Bitmap b) {
        int[] px = new int[S * S];
        b.getPixels(px, 0, S, 0, 0, S, S);
        byte[] out = new byte[S * S / 8];
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                if ((px[y * S + x] & 0xFF) > 127) out[y * (S / 8) + (x >> 3)] |= (byte) (1 << (7 - (x & 7)));
            }
        }
        return out;
    }

    /** Ubah gambar ikon (misalnya dari notifikasi Google Maps) menjadi 1-bit. Null jika hasilnya tidak masuk akal. */
    static byte[] fromBitmap(Bitmap src) {
        if (src == null) return null;
        Bitmap s = Bitmap.createScaledBitmap(src, S, S, true);
        int[] px = new int[S * S];
        s.getPixels(px, 0, S, 0, 0, S, S);
        int n = S * S;
        int transparent = 0, dark = 0;
        int[] lum = new int[n];
        for (int i = 0; i < n; i++) {
            int p = px[i];
            if ((p >>> 24) < 128) transparent++;
            int r = (p >> 16) & 0xFF, g = (p >> 8) & 0xFF, b = p & 0xFF;
            lum[i] = (r * 299 + g * 587 + b * 114) / 1000;
            if (lum[i] < 128) dark++;
        }
        boolean[] on = new boolean[n];
        boolean useAlpha = transparent > n / 10;
        boolean arrowDark = dark < n - dark;
        int count = 0;
        for (int i = 0; i < n; i++) {
            if (useAlpha) on[i] = (px[i] >>> 24) >= 128;
            else on[i] = arrowDark ? lum[i] < 128 : lum[i] >= 128;
            if (on[i]) count++;
        }
        double ratio = count / (double) n;
        if (ratio < 0.02 || ratio > 0.70) return null;
        byte[] out = new byte[n / 8];
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                if (on[y * S + x]) out[y * (S / 8) + (x >> 3)] |= (byte) (1 << (7 - (x & 7)));
            }
        }
        return out;
    }

    private static Paint stroke(float w) {
        Paint p = new Paint();
        p.setAntiAlias(false);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(w);
        p.setStrokeJoin(Paint.Join.MITER);
        p.setStrokeCap(Paint.Cap.BUTT);
        return p;
    }

    /** Panah belokan buatan sendiri. angle: 0 lurus, 45, 90 kanan, 135, 180 putar balik (negatif = kiri). */
    static byte[] arrow(int angle, boolean arrive) {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.BLACK);
        Paint line = stroke(6f);
        Paint fill = new Paint();
        fill.setAntiAlias(false);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.WHITE);

        if (arrive) {
            c.drawCircle(24f, 22f, 14f, stroke(5f));
            c.drawCircle(24f, 22f, 6f, fill);
            c.drawRect(10f, 42f, 38f, 46f, fill);
            return pack(b);
        }

        int a = Math.abs(angle);
        boolean left = angle < 0;
        float[] pts;
        float bx, by;
        int dirDeg;
        if (a >= 160) {
            pts = new float[]{34, 46, 34, 18, 16, 18, 16, 30};
            bx = 16; by = 30; dirDeg = 180;
        } else if (a >= 110) {
            pts = new float[]{12, 44, 12, 20, 26, 34};
            bx = 26; by = 34; dirDeg = 135;
        } else if (a >= 70) {
            pts = new float[]{12, 46, 12, 30, 28, 30};
            bx = 28; by = 30; dirDeg = 90;
        } else if (a >= 25) {
            pts = new float[]{14, 46, 14, 36, 28, 22};
            bx = 28; by = 22; dirDeg = 45;
        } else {
            pts = new float[]{24, 46, 24, 14};
            bx = 24; by = 14; dirDeg = 0;
        }
        if (left) {
            for (int i = 0; i < pts.length; i += 2) pts[i] = 47 - pts[i];
            bx = 47 - bx;
        }
        Path path = new Path();
        path.moveTo(pts[0], pts[1]);
        for (int i = 2; i < pts.length; i += 2) path.lineTo(pts[i], pts[i + 1]);
        c.drawPath(path, line);

        double r = Math.toRadians(left ? -dirDeg : dirDeg);
        float dx = (float) Math.sin(r), dy = (float) -Math.cos(r);
        float px = (float) Math.cos(r), py = (float) Math.sin(r);
        Path head = new Path();
        head.moveTo(bx + dx * 14f, by + dy * 14f);
        head.lineTo(bx + px * 11f, by + py * 11f);
        head.lineTo(bx - px * 11f, by - py * 11f);
        head.close();
        c.drawPath(head, fill);
        return pack(b);
    }
}
