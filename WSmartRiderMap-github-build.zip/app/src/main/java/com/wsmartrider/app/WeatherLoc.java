package com.wsmartrider.app;

import android.content.SharedPreferences;
import android.location.Location;

/** Lokasi yang dipakai untuk cuaca: mengikuti GPS HP (otomatis) atau tempat yang diatur sendiri. */
final class WeatherLoc {
    /** Naik setiap pengaturan berubah / diminta perbarui; pemakai membandingkan dengan nilai terakhir yang dilihatnya. */
    static volatile int ver = 0;
    private static volatile double lastLa = 999, lastLo = 999;

    private WeatherLoc() {
    }

    static boolean manual(SharedPreferences sp) {
        return sp.getBoolean("wx_manual", false) && sp.contains("wx_lat") && sp.contains("wx_lon");
    }

    static String manualName(SharedPreferences sp) {
        return sp.getString("wx_name", "");
    }

    static void setAuto(SharedPreferences sp) {
        sp.edit().putBoolean("wx_manual", false).apply();
        lastLa = 999;
        ver++;
    }

    static void setManual(SharedPreferences sp, double la, double lo, String name) {
        sp.edit().putBoolean("wx_manual", true)
                .putString("wx_lat", Double.toString(la))
                .putString("wx_lon", Double.toString(lo))
                .putString("wx_name", name).apply();
        lastLa = 999;
        ver++;
    }

    /** Minta cuaca diperbarui sekarang juga. */
    static void refreshNow() {
        lastLa = 999;
        ver++;
    }

    /** Koordinat yang dipakai untuk cuaca; null bila belum ada GPS dan tidak ada lokasi manual. */
    static double[] pick(SharedPreferences sp, Location gps) {
        if (manual(sp)) {
            try {
                return new double[]{Double.parseDouble(sp.getString("wx_lat", "")),
                        Double.parseDouble(sp.getString("wx_lon", ""))};
            } catch (Exception ignored) {
            }
        }
        return gps == null ? null : new double[]{gps.getLatitude(), gps.getLongitude()};
    }

    static void mark(double la, double lo) {
        lastLa = la;
        lastLo = lo;
    }

    /** true bila titik ini lebih jauh dari {@code meters} dari titik cuaca terakhir (atau belum pernah). */
    static boolean moved(double la, double lo, double meters) {
        if (lastLa > 900) return true;
        float[] r = new float[1];
        Location.distanceBetween(lastLa, lastLo, la, lo, r);
        return r[0] > meters;
    }
}
