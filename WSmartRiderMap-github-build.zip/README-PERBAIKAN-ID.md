# W-Smart Rider — catatan build dan perbaikan

## Build APK lewat GitHub Actions
1. Unggah isi proyek ini ke repository GitHub (branch `main` atau `master`).
2. Buka tab **Actions** dan pilih **Build W-Smart Rider APK**.
3. Jalankan **Run workflow** atau lakukan push ke branch utama.
4. Setelah workflow hijau, buka run tersebut dan unduh artifact **WSmartRiderMap-debug-apk**.

APK debug ini untuk pengujian. Untuk distribusi publik, buat signing release sendiri.

## Firmware OLED
File `desaichronos2oled-9-9.ino` yang disertakan terpisah telah diubah agar layar panggilan tidak menampilkan animasi teks “Berdering...”. Nama penelepon tetap berada di baris atas. Firmware ini tidak otomatis disertakan ke APK; unggah melalui Arduino IDE sesuai board dan library yang dipakai.

## Batasan panggilan WhatsApp
Android tidak menyediakan API publik umum yang memaksa WhatsApp mengangkat panggilan. Aplikasi mencoba menjalankan action Jawab/Answer yang WhatsApp tampilkan di notifikasi. Jika perangkat/versi WhatsApp tidak menyediakan action itu, fitur angkat lewat perangkat eksternal tidak dapat dijamin tanpa perubahan pada dukungan WhatsApp/Android. Pastikan izin akses notifikasi untuk W-Smart Rider aktif dan uji pada HP target.

## Screen mirroring
Screen mirroring penuh memerlukan izin tangkapan layar Android (MediaProjection) dan persetujuan pengguna, serta jalur pengiriman gambar yang sesuai. OLED 128x64 monokrom tidak dapat menampilkan mirror layar HP secara utuh dengan nyaman. Fitur tersebut belum ditambahkan dalam paket ini; perlu dipastikan apakah yang dimaksud adalah mirroring layar HP ke perangkat lain, atau menambahkan menu kontrol/mode mirror pada W-Smart Rider.
